// Hospital LED matrix panel driver — RP2040 replacement for original LPC1768 controller.
//
// This is a FIRST DRAFT built directly from reverse-engineered capture data — see README.md
// for the full writeup. Several details are marked TODO because they're still unconfirmed
// (see "Open questions" in README.md). Treat this as a test harness to validate those
// assumptions against the real panel, not a finished driver.
//
// Bit-banged for now (simple, easy to debug with a logic analyzer alongside it). Once the
// protocol is fully validated, this is a good candidate to move to RP2040 PIO for cleaner
// timing and to free up the CPU core, especially if a scanning/animation refresh rate ends
// up needing more headroom than bit-banging comfortably gives.

#include <Arduino.h>
#include <string.h>
#include "hardware/pio.h"
#include "hardware/clocks.h"

// ---- WS2812 heartbeat (RP2040-Zero onboard LED, GP16) ----
// TEMPORARY BRING-UP AID. The Zero has no plain GPIO LED, so without this there is
// no visible confirmation that a flash actually took and the firmware is running.
// Costs ~30us of blocking time once per second (24 bits x 1.25us), which perturbs
// exactly one panel frame per second. Acceptable while establishing basic life;
// REMOVE once panel timing is being characterised for real, since it injects
// measurable jitter into the very loop you'd be measuring.
//
// PIO-based rather than NOP-bit-banged, with the divider derived from the actual
// clock_get_hz(clk_sys) at runtime — the earlephilhower core runs at 133MHz, not
// the 125MHz a hand-tuned delay loop would assume. That mismatch previously caused
// a solid-white LED on this exact board.
#define PIN_WS2812 16
#define WS2812_PIO pio0
#define WS2812_SM  0

// Standard pico-examples ws2812 program, pre-assembled.
//   0: out    x, 1   side 0 [2]
//   1: jmp    !x, 3  side 1 [1]
//   2: jmp    0      side 1 [4]
//   3: nop           side 0 [4]
static const uint16_t ws2812_program_instructions[] = {
  0x6221, 0x1123, 0x1400, 0xa422,
};
static const struct pio_program ws2812_program = {
  .instructions = ws2812_program_instructions,
  .length = 4,
  .origin = -1,
};

static void ws2812_init(void) {
  uint offset = pio_add_program(WS2812_PIO, &ws2812_program);
  pio_gpio_init(WS2812_PIO, PIN_WS2812);
  pio_sm_set_consecutive_pindirs(WS2812_PIO, WS2812_SM, PIN_WS2812, 1, true);

  pio_sm_config c = pio_get_default_sm_config();
  sm_config_set_wrap(&c, offset + 0, offset + 3);
  sm_config_set_sideset(&c, 1, false, false);
  sm_config_set_sideset_pins(&c, PIN_WS2812);
  sm_config_set_out_shift(&c, false, true, 24);  // shift left, autopull at 24 bits
  sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);

  // 10 PIO cycles per WS2812 bit at 800kHz.
  float div = (float)clock_get_hz(clk_sys) / (800000.0f * 10.0f);
  sm_config_set_clkdiv(&c, div);

  pio_sm_init(WS2812_PIO, WS2812_SM, offset, &c);
  pio_sm_set_enabled(WS2812_PIO, WS2812_SM, true);
}

// Deliberately dim (values kept low): the onboard WS2812 is uncomfortably bright at
// full scale and there's no reason to draw the current during bring-up.
static void ws2812_put(uint8_t r, uint8_t g, uint8_t b) {
  uint32_t grb = ((uint32_t)g << 16) | ((uint32_t)r << 8) | (uint32_t)b;
  pio_sm_put_blocking(WS2812_PIO, WS2812_SM, grb << 8u);
}

// ---- Pin assignments — VERIFIED against physical wiring by continuity test ----
// These were previously placeholders (2,3,4,5,6,7,8,9) that matched NOTHING on the
// actual harness. Every signal was crossed: SRCLK was fed the OE waveform, RCLK was
// fed red pixel data, and OE was driven by address bit A2 — leaving the panel enabled
// for ~half of every frame (vs the original hardware's 6.4% duty). That is the cause
// of both the "display never changes regardless of firmware" symptom and the module
// overheating. The three address lines were never configured as outputs at all and
// floated. Do not change these without re-checking continuity to the IDC header.
//
//                        IDC pin   signal
#define PIN_SRCLK  4   //    1      shift register clock
#define PIN_RCLK   5   //    3      latch
#define PIN_R      6   //    6      red serial data
#define PIN_G      7   //    7      green serial data
#define PIN_OE     9   //    9      output enable (active low)
#define PIN_ADDR0 10   //   11      row address bit 0
#define PIN_ADDR1 11   //   13      row address bit 1
#define PIN_ADDR2 12   //   15      row address bit 2
// IDC pin 2 = GND. GP2, GP3 and GP8 are NOT connected to the panel.
//
// Heartbeat output — GP8 is free (wired to nothing) and adjacent to the panel
// signals, so it can share a logic-analyzer capture as a "firmware is alive" marker.
#define PIN_HEARTBEAT 8

// ---- Panel geometry (confirmed via capture) ----
#define NUM_MODULES        16
#define COLS_PER_MODULE    5
#define TOTAL_COLS         (NUM_MODULES * COLS_PER_MODULE)  // 80
#define NUM_ROWS           7   // physical row commons H1-H7
#define NUM_ADDR_STATES    8   // A0-A2 cycles 0-7 (addr 0 believed non-physical, see README)
#define BITPLANES_PER_ROW  2   // 2 loads observed per address value

// CONFIRMED via hardware test: filling the buffer with the old LED_OFF value (1) lit up
// most of the row, while the one bit set to the old LED_ON value (0) did not appear lit.
// Polarity is the opposite of the original guess:
#define LED_ON  1
#define LED_OFF 0

// Frame buffer: one bit per (row, column), one array per color.
// Index [0] corresponds to address value 0 (currently treated as blank/dummy — see below).
// Real rows are addresses 1-7 mapped to physical rows H1-H7 — TODO confirm this mapping,
// it's currently just assumed identity (addr N -> row N) with no evidence either way.
static uint8_t redBuf[NUM_ROWS][TOTAL_COLS];
static uint8_t greenBuf[NUM_ROWS][TOTAL_COLS];

static volatile uint32_t srclkPulseCount = 0;
static volatile uint32_t oeEnableCount = 0;

static inline void pulseSRCLK() {
  digitalWrite(PIN_SRCLK, HIGH);
  delayMicroseconds(1); // hold time: ensure clock stays high long enough to register
  digitalWrite(PIN_SRCLK, LOW);
  delayMicroseconds(1); // settle time before next bit's data changes
  srclkPulseCount++;
}

static inline void pulseRCLK() {
  digitalWrite(PIN_RCLK, HIGH);
  delayMicroseconds(1); // hold time — same fix applied to SRCLK earlier was missed here.
                        // If RCLK's pulse was too narrow to reliably latch, the panel's
                        // visible output could stay stuck on old data indefinitely,
                        // regardless of what shiftOutRow() sends — matching the observed
                        // "different code, identical display" symptom exactly.
  digitalWrite(PIN_RCLK, LOW);
  delayMicroseconds(1);
}

// SAFETY: panel modules were observed overheating during bring-up testing — almost
// certainly because bit-banged digitalWrite() on this core is much slower than the
// original ~1.14MHz protocol timing, so OE ends up enabled for a much larger fraction
// of time than the low-duty pulses seen in the original captures. Until real OE/SRCLK
// timing has been verified at the Pico's own GPIO pins (panel disconnected) with a
// logic analyzer, FORCE_OE_DISABLED keeps the panel permanently blanked so it's safe
// to flash and run without risk of sustained drive current. Only set this to false
// once you've confirmed OE duty cycle is genuinely low via direct measurement.
// SAFETY-CRITICAL: real per-row OE enable time on the original hardware was ~7-8us
// (measured from the very first captures), not the 70us this firmware used initially.
// That 9x-too-long window is the confirmed cause of the panel heating during bring-up
// (measured actual enabled duty was ~18.8% here vs ~6.4% on the original board).
// Start LOW and only increase gradually while monitoring temperature and using a
// current-limited supply — do not jump back up toward 70us.
#define ROW_ON_TIME_US 8

// Set to 1 to run the walking-column diagnostic, 0 to hold a completely blank frame.
// Start with 0 — if modules 5/6/10/11 still heat with NOTHING commanded on, that's a
// hardware fault local to those modules, not a firmware bug. If they stay cool blank
// but heat again once RUN_WALK_TEST is re-enabled, the problem is in the data framing
// (likely the shift/latch structure assumption — see README open question #3 area).
#define RUN_WALK_TEST 0

// ---- PIN_MAP_TEST: static pin-mapping verification with a DMM ----
// Set to 1 to bypass ALL panel driving. Holds exactly one signal HIGH at a time for
// PIN_MAP_DWELL_MS, everything else LOW, and prints which one is asserted. Probe the
// corresponding IDC pin with a DMM in DC volts (black lead to ground): you should read
// ~5V on the named pin (after the 245) and ~0V everywhere else.
//
// Why this exists: the firmware's pin defines were wrong for the entire bring-up and
// nothing caught it, because every symptom looked like a protocol bug. This test is the
// cheapest thing that would have caught it, and it also verifies the 74HCT245 end to end
// in the same pass. Run it after ANY rewiring, before trusting a single frame of output.
//
// OE is deliberately included in the walk. It is active-LOW, so asserting it HIGH is the
// blanked/safe state — this test never lights the panel.
#define PIN_MAP_TEST 0
#define PIN_MAP_DWELL_MS 3000

#define FORCE_OE_DISABLED true   // SAFE DEFAULT after the pin-mapping fix:
                                 // keep the panel blanked until the corrected mapping
                                 // has been verified on a logic analyzer.

static inline void setOE(bool lit) {
  // OE is active-low per capture data: LOW = panel driving/lit, HIGH = blanked.
  if (FORCE_OE_DISABLED) {
    digitalWrite(PIN_OE, HIGH); // always blanked
    return;
  }
  digitalWrite(PIN_OE, lit ? LOW : HIGH);
  if (lit) oeEnableCount++;
}

static inline void setRowAddress(uint8_t addr) {
  digitalWrite(PIN_ADDR0, (addr >> 0) & 1);
  digitalWrite(PIN_ADDR1, (addr >> 1) & 1);
  digitalWrite(PIN_ADDR2, (addr >> 2) & 1);
}

// Shifts 80 bits of column data (one row's worth) into the R and G chains in parallel.
// TODO (README open question #3): bit order within the 80 assumed sequential
// module0-col0..col4, module1-col0..col4, ... module15-col0..col4. Not yet verified —
// if the lit pattern comes out mirrored or module-shuffled, this is the first place to look.
//
// DIAGNOSTIC: added explicit setup-time delay before the clock edge, and hold-time delays
// inside pulseSRCLK(). Testing the theory that a blank/constant buffer works correctly but
// a single differing bit corrupts the whole row because data isn't held stable long enough
// relative to the clock edge — a single bad bit in a shift register propagates forward and
// can corrupt everything shifted after it, which would explain "one bit commanded -> entire
// row lit."
static void shiftOutRow(const uint8_t *redRow, const uint8_t *greenRow) {
  for (int col = TOTAL_COLS - 1; col >= 0; col--) {
    digitalWrite(PIN_R, redRow[col]);
    digitalWrite(PIN_G, greenRow[col]);
    delayMicroseconds(1); // setup time: let data settle before the clock samples it
    pulseSRCLK();
  }
}

// Drives one full frame: 8 address states, 2 loads each, matching captured timing.
// FIX (was README open question #2 / a standing TODO): the original hardware's address-0
// SECOND load was always 160 bits, not 80, in every capture. This firmware was never
// updated to match — it just shifted 80 bits regardless of address, leaving the back half
// of the real chain holding stale data from the previous cycle. That's the likely cause of
// the full-row-lit corruption seen during walking-test bring-up: a single new bit combining
// with leftover garbage in an under-shifted chain. Fix: shift an extra 80 bits of blank
// (all-off) padding immediately before that specific load's latch, so nothing stale remains.
static uint8_t blankPadRow[TOTAL_COLS]; // stays all LED_OFF (zero-initialized static)

static void refreshFrame() {
  for (int8_t addr = NUM_ADDR_STATES - 1; addr >= 0; addr--) {
    setOE(false); // blank while shifting + latching, matches captured OE-high-during-load

    uint8_t rowIndex = (addr >= 1 && addr <= NUM_ROWS) ? (addr - 1) : 0;

    for (uint8_t plane = 0; plane < BITPLANES_PER_ROW; plane++) {
      // TODO: both planes currently shift the SAME data. Once the brightness/BCM meaning
      // of the 2 planes is confirmed (README open question #5), differentiate them here —
      // e.g. plane 0 = "on at all" mask, plane 1 = "bright" mask, or similar weighting.
      shiftOutRow(redBuf[rowIndex], greenBuf[rowIndex]);
      if (addr == 0 && plane == 1) {
        shiftOutRow(blankPadRow, blankPadRow); // extra 80 bits, matching captured 160-bit load
      }
      pulseRCLK();
    }

    setRowAddress((uint8_t)addr);
    setOE(true);
    delayMicroseconds(ROW_ON_TIME_US);
  }
}

#if PIN_MAP_TEST
struct PinMapEntry { uint8_t gpio; const char *name; const char *idc; };
static const PinMapEntry pinMap[] = {
  { PIN_SRCLK, "SRCLK",  "IDC 1"  },
  { PIN_RCLK,  "RCLK",   "IDC 3"  },
  { PIN_R,     "R data", "IDC 6"  },
  { PIN_G,     "G data", "IDC 7"  },
  { PIN_OE,    "OE",     "IDC 9"  },
  { PIN_ADDR0, "A0",     "IDC 11" },
  { PIN_ADDR1, "A1",     "IDC 13" },
  { PIN_ADDR2, "A2",     "IDC 15" },
};
#define PIN_MAP_COUNT (sizeof(pinMap) / sizeof(pinMap[0]))

static void allPinsLow() {
  for (uint8_t i = 0; i < PIN_MAP_COUNT; i++) digitalWrite(pinMap[i].gpio, LOW);
}

static void runPinMapTest() {
  static uint8_t idx = 0;
  static uint32_t lastStep = 0;
  static bool announced = false;

  if (!announced) {
    allPinsLow();
    Serial.println();
    Serial.println("=== PIN MAP TEST ===");
    Serial.println("DMM in DC volts, black lead to GND, red lead on the named IDC pin.");
    Serial.println("Expect ~5V on the named pin only, ~0V on all others.");
    Serial.println("Panel is never lit in this mode (OE asserted HIGH = blanked).");
    Serial.println();
    announced = true;
    lastStep = millis() - PIN_MAP_DWELL_MS;  // start immediately
  }

  if (millis() - lastStep < PIN_MAP_DWELL_MS) return;
  lastStep = millis();

  allPinsLow();
  digitalWrite(pinMap[idx].gpio, HIGH);

  // Magenta = pin map mode, so it can't be mistaken for the normal green heartbeat.
  ws2812_put(24, 0, 24);

  Serial.print("HIGH: GP");   Serial.print(pinMap[idx].gpio);
  Serial.print("  -> ");      Serial.print(pinMap[idx].name);
  Serial.print("  -> expect ~5V on ");  Serial.println(pinMap[idx].idc);

  idx = (idx + 1) % PIN_MAP_COUNT;
  if (idx == 0) Serial.println("--- full pass complete, repeating ---");
}
#endif

void setup() {
  Serial.begin(115200);
  // Wait briefly for a serial connection so early prints aren't lost, but don't hang
  // forever if nothing's listening (e.g. running on battery with no USB monitor open).
  uint32_t waitStart = millis();
  while (!Serial && (millis() - waitStart) < 3000) { delay(10); }

  // NOTE: target is an RP2040-Zero (V1083 clone), which has NO plain GPIO LED —
  // the onboard LED is a WS2812 on GP16 and needs a protocol driver, not a level.
  // The old pinMode/digitalWrite heartbeat silently did nothing on this board, so
  // "no blinking LED" must NOT be read as "firmware isn't running". Heartbeat is
  // now a GPIO toggle on a spare pin instead, which a logic analyzer can see.
  pinMode(PIN_HEARTBEAT, OUTPUT);
  ws2812_init();
  // Solid blue the moment setup() is reached: distinguishes "flashed and booted"
  // from "flash didn't take" before any of the loop logic has had a chance to run.
  ws2812_put(0, 0, 24);

  pinMode(PIN_SRCLK, OUTPUT);
  pinMode(PIN_RCLK, OUTPUT);
  pinMode(PIN_OE, OUTPUT);
  pinMode(PIN_R, OUTPUT);
  pinMode(PIN_G, OUTPUT);
  pinMode(PIN_ADDR0, OUTPUT);
  pinMode(PIN_ADDR1, OUTPUT);
  pinMode(PIN_ADDR2, OUTPUT);

  digitalWrite(PIN_SRCLK, LOW);
  digitalWrite(PIN_RCLK, LOW);
  setOE(false);

  memset(redBuf, LED_OFF, sizeof(redBuf));
  memset(greenBuf, LED_OFF, sizeof(greenBuf));
  // Explicit: blankPadRow is zero-initialised, which is only "all off" while LED_OFF==0.
  // Set it from the macro so a polarity change can't silently turn the padding all-ON.
  memset(blankPadRow, LED_OFF, sizeof(blankPadRow));

  Serial.println("=== panel driver starting ===");
#if PIN_MAP_TEST
  Serial.println("BUILD: PIN_MAP_TEST - static DMM pin verification, panel not driven");
#else
  Serial.println("BUILD: normal panel drive");
#endif
  Serial.print("SRCLK="); Serial.print(PIN_SRCLK);
  Serial.print(" RCLK=");  Serial.print(PIN_RCLK);
  Serial.print(" OE=");    Serial.print(PIN_OE);
  Serial.print(" R=");     Serial.print(PIN_R);
  Serial.print(" G=");     Serial.print(PIN_G);
  Serial.print(" A0=");    Serial.print(PIN_ADDR0);
  Serial.print(" A1=");    Serial.print(PIN_ADDR1);
  Serial.print(" A2=");    Serial.println(PIN_ADDR2);
  Serial.println("=== walking-column diagnostic: watch row 0, note the physical position");
  Serial.println("=== reported for each printed index (module + column-within-module) ===");
}

// --- Diagnostic mode ---
// Walks a single lit pixel across all 80 columns of row 0 (red first, then green),
// pausing on each one and printing its index + derived module/column-within-module.
// Purpose: empirically map bit index -> physical LED position, rather than guessing
// from theory. Note down what you actually see for each printed line — that mapping
// is what resolves the module/column ordering (README open question #3).
#define WALK_STEP_MS 600

void loop() {
#if PIN_MAP_TEST
  runPinMapTest();
  return;   // never touches refreshFrame() — panel stays dark
#endif

  static uint32_t frameCount = 0;
  static uint32_t lastReport = 0;
  static bool heartbeatState = false;
  static uint32_t lastStep = 0;
  static int walkIndex = 0;
  static bool walkingRed = true;

  refreshFrame();
  frameCount++;

  if (millis() - lastStep >= WALK_STEP_MS) {
    lastStep = millis();

#if RUN_WALK_TEST
    // clear previous bit
    memset(redBuf[0], LED_OFF, TOTAL_COLS);
    memset(greenBuf[0], LED_OFF, TOTAL_COLS);

    int module = walkIndex / COLS_PER_MODULE;
    int colInModule = walkIndex % COLS_PER_MODULE;

    if (walkingRed) {
      redBuf[0][walkIndex] = LED_ON;
    } else {
      greenBuf[0][walkIndex] = LED_ON;
    }

    if (Serial) {
#if RUN_WALK_TEST
      Serial.print(walkingRed ? "RED   " : "GREEN ");
      Serial.print("bit index "); Serial.print(walkIndex);
      Serial.print("  (module "); Serial.print(module);
      Serial.print(", col "); Serial.print(colInModule);
      Serial.println(" within module)");
#else
      Serial.println("blank frame - nothing commanded on");
#endif
    }

    walkIndex++;
    if (walkIndex >= TOTAL_COLS) {
      walkIndex = 0;
      walkingRed = !walkingRed;
      if (Serial) {
        Serial.println(walkingRed ? "--- restarting on RED ---" : "--- switching to GREEN ---");
      }
    }
#else
    // BLANK TEST: buffers stay all-zero (LED_OFF) the whole time — nothing commanded on.
    // Purpose: isolate whether the module 5/6/10/11 heating is a hardware fault (would
    // still happen here, with zero pixels commanded) vs a firmware data-framing bug
    // (should NOT happen here if truly isolated to the walk pattern).
    if (Serial) {
      Serial.println("blank frame - nothing commanded on");
    }
#endif
  }

  // Heartbeat: onboard LED toggles and a status line prints roughly once a second.
  // If you see this in the serial monitor but the panel does nothing, the Pico is
  // definitely running and the problem is downstream (wiring, polarity, or voltage
  // levels) rather than the firmware not executing at all.
  //
  // GUARDED WITH if (Serial): on this mbed/USB-CDC core, Serial.print() can BLOCK the
  // entire loop() — including all GPIO/SRCLK toggling in refreshFrame() — if nothing on
  // the host side is reading the output buffer (e.g. pio device monitor was closed or
  // never opened). That would silently stop the panel signals entirely without any error,
  // which is a serious trap during logic-analyzer bring-up: always confirm the monitor is
  // open and actively connected before capturing, or the capture will show near-zero
  // activity that looks like a firmware bug but is actually a blocked print call.
  if (millis() - lastReport >= 1000) {
    lastReport = millis();
    heartbeatState = !heartbeatState;
    digitalWrite(PIN_HEARTBEAT, heartbeatState);
    // Green/off blink = loop is running and refreshFrame() is returning.
    // If this stops but the board is still powered, the loop has stalled
    // (blocking Serial print is the usual culprit on USB-CDC cores).
    ws2812_put(0, heartbeatState ? 24 : 0, 0);
    if (Serial) {
      Serial.print("alive - frames/s: ");
      Serial.print(frameCount);
      Serial.print("  SRCLK pulses/s: ");
      Serial.print(srclkPulseCount);
      Serial.print("  OE enables/s: ");
      Serial.println(oeEnableCount);
    }
    frameCount = 0;
    srclkPulseCount = 0;
    oeEnableCount = 0;
  }
}
